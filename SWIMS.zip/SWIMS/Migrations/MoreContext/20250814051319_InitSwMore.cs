﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SWIMS.Migrations.MoreContext
{
    /// <inheritdoc />
    public partial class InitSwMore : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SW_role_claims");

            migrationBuilder.DropTable(
                name: "SW_user_claims");

            migrationBuilder.DropTable(
                name: "SW_user_logins");

            migrationBuilder.DropTable(
                name: "SW_user_roles");

            migrationBuilder.DropTable(
                name: "SW_user_tokens");

            migrationBuilder.DropTable(
                name: "SW_roles");

            migrationBuilder.DropTable(
                name: "SW_users");

            migrationBuilder.CreateTable(
                name: "SW_identity",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    desc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    logo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    media_01 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    media_02 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    media_03 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    header = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    signature = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_identity", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SW_forms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    uuid = table.Column<int>(type: "int", nullable: true),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    desc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    form = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    is_approval_01 = table.Column<byte>(type: "tinyint", nullable: true),
                    is_approval_02 = table.Column<byte>(type: "tinyint", nullable: true),
                    is_approval_03 = table.Column<byte>(type: "tinyint", nullable: true),
                    dateModified = table.Column<DateTime>(type: "datetime", nullable: false),
                    SW_identityId = table.Column<int>(type: "int", nullable: false),
                    formData_01 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_02 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_03 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_04 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_05 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_06 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_07 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_08 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_09 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_10 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_11 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_12 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_13 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_14 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_15 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_16 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_17 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_18 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_19 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_20 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_21 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_22 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_23 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_24 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_25 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_26 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_27 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_28 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_29 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_30 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_31 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_32 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_33 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_34 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_35 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_36 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_37 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_38 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_39 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_40 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_41 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_42 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_43 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_44 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_45 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_46 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_47 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_48 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_49 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_50 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_51 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_52 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_53 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_54 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_55 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_56 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_57 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_58 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_59 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_60 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_61 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_62 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_63 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_64 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_65 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_66 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_67 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_68 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_69 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_70 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_71 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_72 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_73 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_74 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_75 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_76 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_77 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_78 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_79 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_80 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_81 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_82 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_83 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_84 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_85 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_86 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_87 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_88 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_89 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_90 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_91 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_92 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_93 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_94 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_95 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_96 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_97 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_98 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_99 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_100 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_101 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_102 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_103 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_104 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_105 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_106 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_107 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_108 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_109 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_110 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_111 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_112 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_113 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_114 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_115 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_116 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_117 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_118 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_119 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_120 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_121 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_122 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_123 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_124 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_125 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_126 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_127 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_128 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_129 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_130 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_131 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_132 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_133 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_134 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_135 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_136 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_137 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_138 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_139 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_140 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_141 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_142 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_143 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_144 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_145 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_146 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_147 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_148 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_149 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_150 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_151 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_152 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_153 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_154 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_155 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_156 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_157 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_158 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_159 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_160 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_161 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_162 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_163 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_164 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_165 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_166 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_167 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_168 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_169 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_170 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_171 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_172 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_173 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_174 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_175 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_176 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_177 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_178 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_179 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_180 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_181 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_182 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_183 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_184 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_185 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_186 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_187 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_188 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_189 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_190 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_191 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_192 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_193 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_194 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_195 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_196 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_197 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_198 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_199 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_200 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_201 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_202 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_203 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_204 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_205 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_206 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_207 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_208 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_209 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_210 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_211 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_212 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_213 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_214 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_215 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_216 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_217 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_218 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_219 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_220 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_221 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_222 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_223 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_224 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_225 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_226 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_227 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_228 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_229 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_230 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_231 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_232 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_233 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_234 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_235 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_236 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_237 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_238 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_239 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_240 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_241 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_242 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_243 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_244 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_245 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_246 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_247 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_248 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_249 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    formData_250 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_forms", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SW_identitySW_forms",
                        column: x => x.SW_identityId,
                        principalTable: "SW_identity",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "SW_forms_tableNames",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SW_formsId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_forms_tableNames", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SW_formsSW_forms_tableNames",
                        column: x => x.SW_formsId,
                        principalTable: "SW_forms",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_FK_SW_identitySW_forms",
                table: "SW_forms",
                column: "SW_identityId");

            migrationBuilder.CreateIndex(
                name: "IX_FK_SW_formsSW_forms_tableNames",
                table: "SW_forms_tableNames",
                column: "SW_formsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SW_forms_tableNames");

            migrationBuilder.DropTable(
                name: "SW_forms");

            migrationBuilder.DropTable(
                name: "SW_identity");

            migrationBuilder.CreateTable(
                name: "SW_roles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_roles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SW_users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SW_role_claims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_role_claims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SW_role_claims_SW_roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "SW_roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SW_user_claims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_user_claims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SW_user_claims_SW_users_UserId",
                        column: x => x.UserId,
                        principalTable: "SW_users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SW_user_logins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_user_logins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_SW_user_logins_SW_users_UserId",
                        column: x => x.UserId,
                        principalTable: "SW_users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SW_user_roles",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_user_roles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_SW_user_roles_SW_roles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "SW_roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SW_user_roles_SW_users_UserId",
                        column: x => x.UserId,
                        principalTable: "SW_users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SW_user_tokens",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SW_user_tokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_SW_user_tokens_SW_users_UserId",
                        column: x => x.UserId,
                        principalTable: "SW_users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SW_role_claims_RoleId",
                table: "SW_role_claims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "SW_roles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_SW_user_claims_UserId",
                table: "SW_user_claims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SW_user_logins_UserId",
                table: "SW_user_logins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_SW_user_roles_RoleId",
                table: "SW_user_roles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "SW_users",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "SW_users",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");
        }
    }
}
