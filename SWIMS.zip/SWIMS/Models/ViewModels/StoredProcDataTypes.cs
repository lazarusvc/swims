﻿namespace SWIMS.Models.ViewModels;

public static class StoredProcDataTypes
{
    public static readonly string[] Allowed = new[]
    {
        "Int","Float","Decimal","Bit","DateTime","NVarChar","UniqueIdentifier","Text"
    };
}
