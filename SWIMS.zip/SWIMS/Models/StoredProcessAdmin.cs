﻿namespace SWIMS.Models
{
    public class StoredProcessAdmin
    {
    }
}
