﻿namespace SWIMS.Models.Security;

public static class DataProtectionPurposes
{
    public const string StoredProcedures = "SWIMS.StoredProcedures";
}
