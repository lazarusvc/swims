﻿using Microsoft.AspNetCore.Authorization;

namespace SWIMS.Services.Auth
{
    public class PublicOrAuthenticatedRequirement : IAuthorizationRequirement { }
}
